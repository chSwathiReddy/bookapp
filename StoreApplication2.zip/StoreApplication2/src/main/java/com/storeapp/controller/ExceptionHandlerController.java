package com.storeapp.controller;

import java.time.LocalDateTime;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

import com.storeapp.exceptions.ErrorMessage;
import com.storeapp.exceptions.ResourseNotFoundException;

@RestController
@ControllerAdvice//aop around advice
public class ExceptionHandlerController {
	@ExceptionHandler(ResourseNotFoundException.class)
    public ResponseEntity<ErrorMessage> handleResouceNotFoundEx(ResourseNotFoundException ex,WebRequest req){
		ErrorMessage detail=new ErrorMessage();
        detail.setContact("ani@gmail.com");
        detail.setErrorMsg(req.getDescription(false));
        detail.setMessage(ex.getMessage());
        detail.setTimestamp(LocalDateTime.now());
        return new ResponseEntity<ErrorMessage>(detail, HttpStatus.NOT_FOUND);
    }
	
	
	@ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorMessage> handleOtherEx(Exception ex,WebRequest req){
		ErrorMessage detail=new ErrorMessage();
        detail.setContact("ani@gmail.com");
        detail.setErrorMsg(req.getDescription(false));
        detail.setMessage(ex.getMessage());
        detail.setTimestamp(LocalDateTime.now());
        return new ResponseEntity<ErrorMessage>(detail, HttpStatus.NOT_FOUND);
    }
	
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
            HttpHeaders headers, HttpStatus status, WebRequest request) {
	 ErrorMessage detail=new ErrorMessage();
        detail.setContact("rgutpa.mtech@gmail.com");
        detail.setErrorMsg(request.getDescription(false));
        detail.setMessage(ex.getMessage());
        detail.setTimestamp(LocalDateTime.now());
        return new ResponseEntity<Object>(detail, HttpStatus.BAD_REQUEST);
    }
}

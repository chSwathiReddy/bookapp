package com.storeapp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

//import com.bookapp.model.dao.Book;
//import com.bookapp.model.dao.Book;
//import com.bookapp.model.service.BookService;
import com.storeapp.entities.Product;
import com.storeapp.service.ProductService;

//.....8083/storeapp/api/product
@RestController
@RequestMapping("api")
public class ProductRestController {
	
	private ProductService productService;
	public ProductRestController(ProductService productService) 
	{
		this.productService = productService;
	}
	
	//get All Products
	@GetMapping(path="product" ,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Product>> getAllProduct(){
		List<Product> products=productService.getAllProduct();
		return ResponseEntity.ok(products);
		
	}
		
		//by product by id
		
		@GetMapping(path="product/{id}" ,produces=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Product> getProductById(@Valid @PathVariable(name = "id")int productId){
			Product product=productService.getProductById(productId);
			return ResponseEntity.ok(product);
			
		}
		//using heteos
		
//		  @GetMapping(path="/product2/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
//		    public EntityModel<Product> getProductByIdV2(@PathVariable(name = "id")int productId){
//		        //....../storeapp/api/product2/7
//		        Link link=linkTo(methodOn(ProductRestController.class).getProductByIdV2(productId))
//		                .withSelfRel();
//		        System.out.println("----------------------------");
//		        System.out.println(link.toString());
//		        Product product=productService.getProductById(productId);
//		        product.add(link);
//		        return EntityModel.of(product);
//		    }
//			
		
		//adding
		@PostMapping(path="product" ,
				produces=MediaType.APPLICATION_JSON_VALUE,
				consumes=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Product> addProduct(@RequestBody Product product) {
			Product addedProd=productService.addProduct(product);
			return new ResponseEntity<Product>(HttpStatus.CREATED);
		}
		
		//updating
		@PutMapping(path="product/{id}" ,
				produces=MediaType.APPLICATION_JSON_VALUE,
				consumes=MediaType.APPLICATION_JSON_VALUE)
		public Product updateBook(@PathVariable(name = "id")int productId,@RequestBody Product product ) {
			Product updateProd=productService.updateProduct(productId,product);
			return updateProd;
		}
		
		//deleting
		@DeleteMapping(path="product/{id}" ,
				produces=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Product> deleteProduct(@PathVariable(name = "id")int productId) {
			Product productDelete=productService.deleteProduct(productId);
			return new ResponseEntity<Product>(HttpStatus.NO_CONTENT);
		}
	
}

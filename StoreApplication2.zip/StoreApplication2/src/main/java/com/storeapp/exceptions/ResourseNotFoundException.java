package com.storeapp.exceptions;

import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus()
public class ResourseNotFoundException extends RuntimeException{

	
	private static final long serialVersionUID = -9034602348977242287L;
	public ResourseNotFoundException(String message) {
		super(message);
	}

	
	

}

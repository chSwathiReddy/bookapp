package com.storeapp.entities;

public class Name1 {

	private String personName;

	public Name1() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPersonName() {
		return personName;
	}

	public void setPersonName(String personName) {
		this.personName = personName;
	}

	public Name1(String personName) {
		super();
		this.personName = personName;
	}
	
}

package com.storeapp.entities;

public class Name2 {

	private String personFirstName;
	private String personLastName;

	public Name2() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPersonFirstName() {
		return personFirstName;
	}

	public void setPersonFirstName(String personFirstName) {
		this.personFirstName = personFirstName;
	}

	public String getPersonLastName() {
		return personLastName;
	}

	public void setPersonLastName(String personLastName) {
		this.personLastName = personLastName;
	}

	public Name2(String personFirstName, String personLastName) {
		super();
		this.personFirstName = personFirstName;
		this.personLastName = personLastName;
	}

	
}

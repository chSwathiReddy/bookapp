package com.storeapp.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class ScheduleJob {
	private Logger logger =LoggerFactory.getLogger(ScheduleJob.class);
	
	@Autowired
	private ProductService productService;
	
	//whenever u r defining a method for scheduling i must not return anything.not take any parameters
	@Scheduled(cron="0,10 * * * * *")
	public void doScedulingAfterEach30Sec() {
		logger.info("doScedulingAfterEach30Sec is called");
		logger.info("no of products in db:"+productService.getAllProduct().size());
		productService.evictCache();
	}
}
